import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../services/product.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
})
export class ProductDetailComponent implements OnInit {
  product: any = {};
  user: any = null; // User details if logged in
  succMsg: string | null = null; // Success message
  errorMsg: string | null = null; // Error message

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const productId = this.route.snapshot.params['id'];
    this.loadProduct(productId);
    this.loadUser();
  }

  loadProduct(productId: string): void {
    this.productService.getProductById(productId).subscribe({
      next: (data) => (this.product = data),
      error: () => (this.errorMsg = 'Product not found'),
    });
  }

  loadUser(): void {
    this.userService.getCurrentUser().subscribe({
      next: (userData) => (this.user = userData),
      error: () => (this.user = null), // User is not logged in
    });
  }

  addToCart(productId: number): void {
    if (!this.user) {
      this.navigateToSignIn();
      return;
    }

    this.productService.addToCart(productId, this.user.id).subscribe({
      next: () => (this.succMsg = 'Product added to cart successfully!'),
      error: () => (this.errorMsg = 'Failed to add product to cart.'),
    });
  }

  navigateToSignIn(): void {
    this.router.navigate(['/signin']);
  }
}
