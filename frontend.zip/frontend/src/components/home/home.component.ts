import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  categories: any[] = [];
  products: any[] = [];

  constructor(private homeService: HomeService) {}

  ngOnInit(): void {
    // Fetch categories and products from the service
    this.getCategories();
    this.getProducts();
  }

  getCategories(): void {
    this.homeService.getCategories().subscribe((data: any) => {
      this.categories = data;
    });
  }

  getProducts(): void {
    this.homeService.getProducts().subscribe((data: any) => {
      this.products = data;
    });
  }
}
