import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  private baseUrl = 'http://localhost:8080/api/user';  // Update this URL based on your backend

  constructor(private http: HttpClient) {}

  updateProfile(user: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/update-profile`, user);
  }
}
