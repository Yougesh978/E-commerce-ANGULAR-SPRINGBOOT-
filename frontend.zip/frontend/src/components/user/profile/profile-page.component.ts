import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../services/profile.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  user: any = {
    name: '',
    mobileNumber: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    profileImage: '',
    role: '',
    isEnable: '',
  };

  password: any = {
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  };

  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private profileService: ProfileService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.userService.getUserProfile().subscribe((userData) => {
      this.user = userData;
    });
  }

  updateProfile(): void {
    this.profileService.updateProfile(this.user).subscribe(
      (response) => {
        this.successMessage = 'Profile updated successfully!';
      },
      (error) => {
        this.errorMessage = 'Error updating profile. Please try again.';
      }
    );
  }

  changePassword(): void {
    if (this.password.newPassword === this.password.confirmPassword) {
      this.userService.changePassword(this.password).subscribe(
        (response) => {
          this.successMessage = 'Password changed successfully!';
        },
        (error) => {
          this.errorMessage = 'Error changing password. Please try again.';
        }
      );
    } else {
      this.errorMessage = 'Passwords do not match.';
    }
  }

  onFileChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.user.profileImage = file.name;
    }
  }
}
