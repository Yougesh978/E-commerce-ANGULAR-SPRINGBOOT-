import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
  carts: any[] = [];
  totalOrderPrice: number = 0;
  succMsg: string | null = null;
  errorMsg: string | null = null;

  constructor(private cartService: CartService) {}

  ngOnInit(): void {
    this.getCartItems();
  }

  getCartItems(): void {
    this.cartService.getCartItems().subscribe(
      (response) => {
        this.carts = response.carts;
        this.totalOrderPrice = response.totalOrderPrice;
      },
      (error) => {
        this.errorMsg = 'Failed to fetch cart items.';
      }
    );
  }

  getImagePath(imageName: string): string {
    return `/img/product_img/${imageName}`;
  }

  updateQuantity(cartId: number, action: 'increase' | 'decrease'): void {
    this.cartService.updateCartQuantity(cartId, action).subscribe(
      (response) => {
        this.getCartItems(); // Refresh the cart after update
      },
      (error) => {
        this.errorMsg = 'Failed to update cart quantity.';
      }
    );
  }
}
