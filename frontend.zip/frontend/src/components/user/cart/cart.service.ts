import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private baseUrl = 'http://localhost:8080/api/cart'; // Update with your backend API endpoint

  constructor(private http: HttpClient) {}

  // Fetch cart items from backend
  getCartItems(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/items`);
  }

  // Update cart quantity (increase or decrease)
  updateCartQuantity(cartId: number, action: 'increase' | 'decrease'): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/updateQuantity`, { cartId, action });
  }
}
