import { Component, OnInit } from '@angular/core';
import { OrderService } from '../services/order.service';

@Component({
  selector: 'app-order-page',
  templateUrl: './order-page.component.html',
  styleUrls: ['./order-page.component.css'],
})
export class OrderPageComponent implements OnInit {
  order: any = {
    firstName: '',
    lastName: '',
    email: '',
    mobileNo: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    paymentType: '',
  };
  orderPrice: number = 1000; // Example price
  totalOrderPrice: number = this.orderPrice + 250 + 100; // Total price includes delivery and tax

  constructor(private orderService: OrderService) {}

  ngOnInit(): void {}

  placeOrder(): void {
    this.orderService.placeOrder(this.order).subscribe(
      (response) => {
        // Handle success
        console.log('Order placed successfully:', response);
      },
      (error) => {
        // Handle error
        console.error('Error placing order:', error);
      }
    );
  }
}
