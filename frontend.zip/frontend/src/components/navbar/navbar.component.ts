import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  user: any = null; // Replace with actual user data from service
  categories: any[] = []; // Replace with actual categories from service
  countCart: number = 0; // Replace with actual cart count from service

  constructor() {}

  ngOnInit(): void {
    // Fetch user and categories using service
  }
}
