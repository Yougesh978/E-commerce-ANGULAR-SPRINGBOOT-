import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  searchQuery = '';
  selectedCategory: string | null = null;
  products: any[] = [];
  categories: string[] = [];
  totalElements = 0;
  totalPages = 0;
  currentPage = 1;
  isFirst = true;
  isLast = false;

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadCategories();
    this.loadProducts();
  }

  loadCategories(): void {
    this.productService.getCategories().subscribe((data) => {
      this.categories = data;
    });
  }

  loadProducts(): void {
    this.productService
      .getProducts(this.currentPage - 1, this.selectedCategory, this.searchQuery)
      .subscribe((data) => {
        this.products = data.content;
        this.totalElements = data.totalElements;
        this.totalPages = data.totalPages;
        this.isFirst = data.first;
        this.isLast = data.last;
      });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadProducts();
  }

  onCategorySelect(category: string): void {
    this.selectedCategory = category;
    this.currentPage = 1;
    this.loadProducts();
  }

  onPageChange(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.loadProducts();
    }
  }

  get pages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }
}
