import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  successMessage: string | null = null;
  errorMessage: string | null = null;

  constructor(private fb: FormBuilder) {
    // Initialize the form group with form controls
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnInit(): void {
    // Optional: Reset messages on load
    this.successMessage = null;
    this.errorMessage = null;
  }

  // Getter for easy access to email form control
  get email() {
    return this.forgotPasswordForm.get('email');
  }

  // Handle form submission
  onSubmit(): void {
    if (this.forgotPasswordForm.valid) {
      const email = this.forgotPasswordForm.value.email;

      // Simulating a service call
      // Replace this with actual API call
      console.log(`Sending forgot password email to: ${email}`);

      // Simulate success or error response
      if (email === 'success@example.com') {
        this.successMessage = 'Password reset link sent successfully!';
        this.errorMessage = null;
        this.forgotPasswordForm.reset();
      } else {
        this.successMessage = null;
        this.errorMessage = 'Failed to send reset link. Please try again.';
      }
    }
  }
}
