import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../services/admin.service';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css'],
})
export class AddAdminComponent {
  adminForm: FormGroup;
  succMsg: string | null = null;
  errorMsg: string | null = null;
  selectedFile: File | null = null;

  constructor(private fb: FormBuilder, private adminService: AdminService) {
    this.adminForm = this.fb.group(
      {
        name: ['', Validators.required],
        mobileNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
        email: ['', [Validators.required, Validators.email]],
        address: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        pincode: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]],
        password: ['', Validators.required],
        confirmPassword: ['', Validators.required],
        img: [''],
      },
      {
        validators: this.passwordMatchValidator,
      }
    );
  }

  passwordMatchValidator(form: FormGroup): { [key: string]: boolean } | null {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  onFileChange(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  onSubmit(): void {
    if (this.adminForm.invalid) return;

    const formData = new FormData();
    Object.entries(this.adminForm.value).forEach(([key, value]) => {
      formData.append(key, value);
    });

    if (this.selectedFile) {
      formData.append('img', this.selectedFile);
    }

    this.adminService.addAdmin(formData).subscribe({
      next: (response) => (this.succMsg = 'Admin added successfully!'),
      error: (err) => (this.errorMsg = 'Failed to add admin.'),
    });
  }
}
