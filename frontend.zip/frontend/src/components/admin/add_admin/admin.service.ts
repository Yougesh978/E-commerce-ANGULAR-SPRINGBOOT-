import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private baseUrl = 'http://localhost:8080/api/admin'; // Update with actual endpoint

  constructor(private http: HttpClient) {}

  addAdmin(data: FormData): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/save-admin`, data);
  }
}
