import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CategoryService } from '../services/category.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css'],
})
export class AddCategoryComponent implements OnInit {
  categoryForm: FormGroup;
  categories: any[] = [];
  totalCategories: number = 0;
  pageNo: number = 1;
  pages: number[] = [];
  succMsg: string | null = null;
  errorMsg: string | null = null;
  selectedFile: File | null = null;
  isFirstPage: boolean = false;
  isLastPage: boolean = false;

  constructor(
    private fb: FormBuilder,
    private categoryService: CategoryService,
    private router: Router
  ) {
    this.categoryForm = this.fb.group({
      name: ['', Validators.required],
      isActive: ['true', Validators.required],
    });
  }

  ngOnInit(): void {
    this.fetchCategories();
  }

  fetchCategories(): void {
    this.categoryService.getCategories(this.pageNo).subscribe((response: any) => {
      this.categories = response.categories;
      this.totalCategories = response.totalElements;
      this.pageNo = response.pageNo;
      this.pages = Array.from({ length: response.totalPages }, (_, i) => i + 1);
      this.isFirstPage = this.pageNo === 1;
      this.isLastPage = this.pageNo === response.totalPages;
    });
  }

  onFileChange(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  getImagePath(imageName: string): string {
    return `/img/category_img/${imageName}`;
  }

  onSubmit(): void {
    if (this.categoryForm.invalid) return;

    const formData = new FormData();
    formData.append('name', this.categoryForm.value.name);
    formData.append('isActive', this.categoryForm.value.isActive);
    if (this.selectedFile) {
      formData.append('file', this.selectedFile);
    }

    this.categoryService.addCategory(formData).subscribe(
      (response) => {
        this.succMsg = 'Category added successfully!';
        this.fetchCategories(); // Refresh categories list
        this.categoryForm.reset();
      },
      (error) => {
        this.errorMsg = 'Failed to add category.';
      }
    );
  }

  deleteCategory(id: number): void {
    this.categoryService.deleteCategory(id).subscribe(
      () => {
        this.succMsg = 'Category deleted successfully!';
        this.fetchCategories();
      },
      () => {
        this.errorMsg = 'Failed to delete category.';
      }
    );
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.pages.length) {
      this.pageNo = page;
      this.fetchCategories();
    }
  }
}
