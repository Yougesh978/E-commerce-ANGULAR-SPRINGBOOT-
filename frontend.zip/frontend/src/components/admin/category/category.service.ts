import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CategoryService {
  private baseUrl = 'http://localhost:8080/api/categories'; // Update with your backend API endpoint

  constructor(private http: HttpClient) {}

  getCategories(pageNo: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/category?pageNo=${pageNo}`);
  }

  addCategory(data: FormData): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/saveCategory`, data);
  }

  deleteCategory(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/deleteCategory/${id}`);
  }
}
