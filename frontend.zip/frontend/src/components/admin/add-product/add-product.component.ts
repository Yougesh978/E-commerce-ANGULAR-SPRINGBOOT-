import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
})
export class AddProductComponent implements OnInit {
  productForm: FormGroup;
  succMsg: string | null = null;
  errorMsg: string | null = null;
  categories: Array<{ name: string }> = [];
  selectedFile: File | null = null;

  constructor(private fb: FormBuilder, private productService: ProductService) {
    this.productForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      category: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(0)]],
      isActive: ['true', Validators.required],
      stock: ['', [Validators.required, Validators.min(0)]],
      img: [''],
    });
  }

  ngOnInit(): void {
    this.fetchCategories();
  }

  fetchCategories(): void {
    // Replace with actual service call to fetch categories
    this.productService.getCategories().subscribe({
      next: (data) => (this.categories = data),
      error: () => (this.errorMsg = 'Failed to load categories'),
    });
  }

  onFileChange(event: any): void {
    this.selectedFile = event.target.files[0];
  }

  onSubmit(): void {
    if (this.productForm.invalid) return;

    const formData = new FormData();
    Object.entries(this.productForm.value).forEach(([key, value]) => {
      formData.append(key, value as string);
    });

    if (this.selectedFile) {
      formData.append('file', this.selectedFile);
    }

    this.productService.addProduct(formData).subscribe({
      next: () => {
        this.succMsg = 'Product added successfully!';
        this.productForm.reset();
      },
      error: () => (this.errorMsg = 'Failed to add product.'),
    });
  }
}
